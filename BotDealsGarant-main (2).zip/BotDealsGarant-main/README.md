# BotDealsGarant

Телеграм бот гарант, позволит провести вам безопасную игровую сделку между пользователями, включает такой функционал,
как проведение гарантированной сделки, связь с тех. поддержкой через бота, возможность оставить отзыв о платформе,
профиль пользователя с его статистикой, удобное админ менб интегрированное в бото, которое позволит просмотреть
пользователкй и сделать рассылку

### EnglishDescription

Telegram bot guarantor will allow you to conduct a safe gaming transaction between users, includes such functionality
as conducting a guaranteed transaction, communication with those. support through a bot, the ability to leave feedback
about the platform, a user profile with its statistics, a convenient admin menu integrated into the bot, which
will allow you to view the user and make a newsletter

![Python](https://img.shields.io/badge/python-090909?style=for-the-badge&logo=python&logoColor=ffdd54)
![Postgres](https://img.shields.io/badge/postgres-090909?style=for-the-badge&logo=postgresql&logoColor=blue)
![Docker](https://img.shields.io/badge/docker-090909?style=for-the-badge&logo=docker&logoColor=blue)
![Aiogram](https://img.shields.io/badge/aiogram-090909?style=for-the-badge&logo=aiogram&logoColor=red)